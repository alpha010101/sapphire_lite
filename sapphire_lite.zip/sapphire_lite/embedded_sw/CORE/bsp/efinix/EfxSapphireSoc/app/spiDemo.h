/*******************************************************************************
*
* @file spiDemo.h
*
* @brief Header file define SPI_0 Controller for spiDemo
*
******************************************************************************/
#pragma once

#define SPI SYSTEM_SPI_0_IO_CTRL
